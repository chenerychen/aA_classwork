class Player
    attr_reader :name

    def initialize
        @name = gets.chomp
    end




end