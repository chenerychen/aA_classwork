class AiPlayer





end